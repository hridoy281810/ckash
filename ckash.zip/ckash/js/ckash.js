

let totalBalance = document.getElementById('total_balance')
let cashInInputFeild = document.getElementById('cash_in')
let cashInButton = document.getElementById('cashin_button');

// totalCashOut statrt 

let totalCashOut = document.getElementById('total_cashout')
let cashOutInputFeild = document.getElementById('cash_out_input')
let cashOutButton = document.getElementById('cash_out');

// total_send_mony start  
let totalendMony = document.getElementById('total_send_mony')
let sendMonyInputFeild = document.getElementById('send_mony_input')
let sendMonyutton = document.getElementById('send_mony')

// total mobile recharge
let totalMobaileRecharge = document.getElementById('total_mobile_recharge')
let MobileRechargeInputFeild = document.getElementById('mobile_recharge_input')
let mobileRechargeButton = document.getElementById('mobile_recharge')


// cashin_in start 
cashInButton.addEventListener('click', function(){
if(cashInInputFeild.value==''){
    cashInInputFeild.style.borderColor="red"
    cashInInputFeild.focus()
}
else{
    let cashInInputConvert = parseFloat(cashInInputFeild.value)
    let tatoalBalnceConvert = parseFloat(totalBalance.innerText)
    totalBalance.innerText = cashInInputConvert + tatoalBalnceConvert
    cashInInputFeild.value = ''
   
}

}) 
cashOutButton.addEventListener('click', function(){


if(cashOutInputFeild.value== '' ||totalBalance.innerText < cashOutInputFeild.value){
    cashOutInputFeild.style.borderColor="red"
    alert('Invalid Ammount')
    cashOutInputFeild.focus()
    cashOutInputFeild.value = ''
}
else{
    let cashOutInputConvert = parseFloat(cashOutInputFeild.value)
let totalCashOutConvert = parseFloat(totalCashOut.innerText)
let upadteCashOut = cashOutInputConvert + totalCashOutConvert
 
totalCashOut.innerText = upadteCashOut

let ubdateTotalBalance = totalBalance.innerText - cashOutInputFeild.value
 
totalBalance.innerText = ubdateTotalBalance
cashOutInputFeild.value = ''
}

}) 

sendMonyutton.addEventListener('click' , function(){
    if(sendMonyInputFeild.value== '' ||totalBalance.innerText < sendMonyInputFeild.value){
        sendMonyInputFeild.style.borderColor="red"
        alert('Invalid Ammount')
        sendMonyInputFeild.focus()
        sendMonyInputFeild.value = ''

    }
    else{
        let sendMonyInputFeildConvert = parseFloat(sendMonyInputFeild.value)
        let totalendMonyConvert = parseFloat(totalendMony.innerText)
        let updateSendMony = sendMonyInputFeildConvert + totalendMonyConvert
        totalendMony.innerText = updateSendMony
        let updatetotalBalance = totalBalance.innerText - sendMonyInputFeild.value
        totalBalance.innerText = updatetotalBalance
        sendMonyInputFeild.value = ''
    }
 
})


mobileRechargeButton.addEventListener('click' , function(){
    if(MobileRechargeInputFeild.value== '' ||totalBalance.innerText < MobileRechargeInputFeild.value){
        MobileRechargeInputFeild.style.borderColor="red"
        alert('Invalid Ammount')
        MobileRechargeInputFeild.focus()
        MobileRechargeInputFeild.value = ''
    }
    else{
        let MobileRechargeInputFeildConvert = parseFloat(MobileRechargeInputFeild.value)
        let totalMobaileRechargeConvert = parseFloat(totalMobaileRecharge.innerText)
        let updateMobileRecharge = MobileRechargeInputFeildConvert + totalMobaileRechargeConvert
        totalMobaileRecharge.innerText = updateMobileRecharge
        let updatetotalBalance = totalBalance.innerText - MobileRechargeInputFeild.value
        totalBalance.innerText = updatetotalBalance
        MobileRechargeInputFeild.value = ''
    }
 
})


    