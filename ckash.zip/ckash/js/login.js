let yourEmail = 'muhib';
let yourPassword = '123456789';
let email = document.getElementById('exampleInputEmail1')
let password = document.getElementById('exampleInputPassword1')
let login_button = document.getElementById('login_button')
function login(){
    let emailVlaue = email.value
    let passwordVlaue = password.value
    if (document.getElementById('exampleInputEmail1').value==""){
        alert('Please enter your email/User name')
    }
    else if (document.getElementById('exampleInputEmail1').value !=yourEmail){
        alert('Encoruct email/User')
    }
    else if (document.getElementById('exampleInputPassword1').value ==''){
        alert('Please enter your password')
    }
    else if (passwordVlaue == password){
        alert('Password cant be password')
    }
    // else if(password.value.length <= 9){
    //     alert('password must be 9 charecters')
    // }
    else if (passwordVlaue != yourPassword){
        alert('Password Is Incorrect')
    }
    else if(yourEmail == emailVlaue && yourPassword == passwordVlaue){
        window.location.href='ckash.html'
    }
    else{
        alert('good bye')
        
    }
        email.value = ''
        password.value =''

} 
